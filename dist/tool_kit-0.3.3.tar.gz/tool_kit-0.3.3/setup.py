# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['tool_kit']

package_data = \
{'': ['*']}

install_requires = \
['SQLAlchemy>=1.4.31,<2.0.0',
 'sentry-sdk>=1.5.4,<2.0.0',
 'sshtunnel>=0.4.0,<0.5.0']

setup_kwargs = {
    'name': 'tool-kit',
    'version': '0.3.3',
    'description': 'generally useful components',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
